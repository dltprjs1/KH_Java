package exam;

import java.util.Scanner;

public class JAVA과제13 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("학생수를 입력해주십시오. :");
		int qqq [] = new int[scan.nextInt()];
		String name = "";
		int kor = 0;
		int eng=0;
		int mat=0;
		int sum=0;
		double avg=0.0;
		String grade = "";
		int rank = 0;
		
		
		for(int i=0;i<qqq.length;i++) {
			System.out.print("이름 입력 :");
			name=scan.next();
			System.out.print("국어점수 입력 :");
			kor=scan.nextInt();
			System.out.print("영어점수 입력 :");
			eng=scan.nextInt();
			System.out.print("수학점수 입력 :");
			mat=scan.nextInt();
			sum = kor+eng+mat;
			avg = sum/ (double)4.0;
			grade = "";
			if(avg >= 90) {
				grade = "A학점";
			}else if (avg >=80) {
				grade = "B학점";
			}else if (avg >=70) {
				grade = "C학점";
			}else if (avg >=60) {
				grade = "D학점";
			}else if (avg <60) {
				grade = "F학점";
			}
			System.out.println("=============================================");
			System.out.println("이름 : "+name+"\t총점 : "+sum+"\t 평균 : "+avg+"학점 : "+grade+"순위 :"+rank);
			}
		
	}

}
