package Exam;

public interface Shape {

	double findArea();
}
